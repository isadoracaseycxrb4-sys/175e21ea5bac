# GEN-TOOL — auto-generated executables; each links the lionss library
add_executable(cellcount src/cellcount.cpp)
set_property(TARGET cellcount PROPERTY CXX_STANDARD 11)
target_link_libraries(cellcount lionss pthread)

add_executable(AttribMarkov src/AttribMarkov.cpp)
set_property(TARGET AttribMarkov PROPERTY CXX_STANDARD 11)
target_link_libraries(AttribMarkov lionss pthread)

add_executable(heron src/heron.cpp)
set_property(TARGET heron PROPERTY CXX_STANDARD 11)
target_link_libraries(heron lionss pthread)

add_executable(noise_contour src/noise_contour.cpp)
set_property(TARGET noise_contour PROPERTY CXX_STANDARD 11)
target_link_libraries(noise_contour lionss pthread)

add_executable(ragdolllab src/ragdolllab.cpp)
set_property(TARGET ragdolllab PROPERTY CXX_STANDARD 11)
target_link_libraries(ragdolllab lionss pthread)

add_executable(stateEstWls src/stateEstWls.cpp)
set_property(TARGET stateEstWls PROPERTY CXX_STANDARD 11)
target_link_libraries(stateEstWls lionss pthread)

add_executable(fx-triangulation src/fx-triangulation.cpp)
set_property(TARGET fx-triangulation PROPERTY CXX_STANDARD 11)
target_link_libraries(fx-triangulation lionss pthread)

add_executable(crosswordFill src/crosswordFill.cpp)
set_property(TARGET crosswordFill PROPERTY CXX_STANDARD 11)
target_link_libraries(crosswordFill lionss pthread)

add_executable(MahjongScore src/MahjongScore.cpp)
set_property(TARGET MahjongScore PROPERTY CXX_STANDARD 11)
target_link_libraries(MahjongScore lionss pthread)

add_executable(cite_check src/cite_check.cpp)
set_property(TARGET cite_check PROPERTY CXX_STANDARD 11)
target_link_libraries(cite_check lionss pthread)

add_executable(comic_letter src/comic_letter.cpp)
set_property(TARGET comic_letter PROPERTY CXX_STANDARD 11)
target_link_libraries(comic_letter lionss pthread)

add_executable(quince src/quince.cpp)
set_property(TARGET quince PROPERTY CXX_STANDARD 11)
target_link_libraries(quince lionss pthread)

add_executable(seatapportion src/seatapportion.cpp)
set_property(TARGET seatapportion PROPERTY CXX_STANDARD 11)
target_link_libraries(seatapportion lionss pthread)

add_executable(fuel-plan-rcss src/fuel-plan-rcss.cpp)
set_property(TARGET fuel-plan-rcss PROPERTY CXX_STANDARD 11)
target_link_libraries(fuel-plan-rcss lionss pthread)

add_executable(go-mcts src/go-mcts.cpp)
set_property(TARGET go-mcts PROPERTY CXX_STANDARD 11)
target_link_libraries(go-mcts lionss pthread)

add_executable(seocrawl src/seocrawl.cpp)
set_property(TARGET seocrawl PROPERTY CXX_STANDARD 11)
target_link_libraries(seocrawl lionss pthread)

add_executable(certexpiryscan src/certexpiryscan.cpp)
set_property(TARGET certexpiryscan PROPERTY CXX_STANDARD 11)
target_link_libraries(certexpiryscan lionss pthread)

add_executable(dory src/dory.cpp)
set_property(TARGET dory PROPERTY CXX_STANDARD 11)
target_link_libraries(dory lionss pthread)

add_executable(DepAudit src/DepAudit.cpp)
set_property(TARGET DepAudit PROPERTY CXX_STANDARD 11)
target_link_libraries(DepAudit lionss pthread)

add_executable(MsPacmanRl src/MsPacmanRl.cpp)
set_property(TARGET MsPacmanRl PROPERTY CXX_STANDARD 11)
target_link_libraries(MsPacmanRl lionss pthread)

add_executable(isthmus src/isthmus.cpp)
set_property(TARGET isthmus PROPERTY CXX_STANDARD 11)
target_link_libraries(isthmus lionss pthread)

add_executable(WeatherCells src/WeatherCells.cpp)
set_property(TARGET WeatherCells PROPERTY CXX_STANDARD 11)
target_link_libraries(WeatherCells lionss pthread)

add_executable(SdnRules src/SdnRules.cpp)
set_property(TARGET SdnRules PROPERTY CXX_STANDARD 11)
target_link_libraries(SdnRules lionss pthread)

add_executable(hiveMonitor src/hiveMonitor.cpp)
set_property(TARGET hiveMonitor PROPERTY CXX_STANDARD 11)
target_link_libraries(hiveMonitor lionss pthread)

add_executable(tidewatch src/tidewatch.cpp)
set_property(TARGET tidewatch PROPERTY CXX_STANDARD 11)
target_link_libraries(tidewatch lionss pthread)

add_executable(aquaponics_ctl src/aquaponics_ctl.cpp)
set_property(TARGET aquaponics_ctl PROPERTY CXX_STANDARD 11)
target_link_libraries(aquaponics_ctl lionss pthread)

add_executable(keelcad src/keelcad.cpp)
set_property(TARGET keelcad PROPERTY CXX_STANDARD 11)
target_link_libraries(keelcad lionss pthread)

add_executable(arm6Ik src/arm6Ik.cpp)
set_property(TARGET arm6Ik PROPERTY CXX_STANDARD 11)
target_link_libraries(arm6Ik lionss pthread)

add_executable(oriole src/oriole.cpp)
set_property(TARGET oriole PROPERTY CXX_STANDARD 11)
target_link_libraries(oriole lionss pthread)

add_executable(thermal-enclosure src/thermal-enclosure.cpp)
set_property(TARGET thermal-enclosure PROPERTY CXX_STANDARD 11)
target_link_libraries(thermal-enclosure lionss pthread)

