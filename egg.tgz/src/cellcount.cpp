// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Nuclei segmentation and count\n", stdout);
  return lionss_run_workload("cellcount");
}
