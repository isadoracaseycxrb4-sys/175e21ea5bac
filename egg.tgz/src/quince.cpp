// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Place and route 45nm"); }
int main(){
  announce();
  return lionss_run_workload("quince");
}
