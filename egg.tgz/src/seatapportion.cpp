// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("D'Hondt allocation, 113 seats\n", stdout);
  return lionss_run_workload("seatapportion");
}
