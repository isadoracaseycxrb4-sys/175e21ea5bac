// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Weighted least-squares estimate"); }
int main(){
  announce();
  return lionss_run_workload("stateEstWls");
}
