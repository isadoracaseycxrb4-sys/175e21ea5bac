// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Score with yaku detection"); }
int main(){
  announce();
  return lionss_run_workload("MahjongScore");
}
