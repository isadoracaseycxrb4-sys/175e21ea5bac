// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Verify citation formats\n", stdout);
  return lionss_run_workload("cite_check");
}
