// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Cellular weather, 7 in-game days\n", stdout);
  return lionss_run_workload("WeatherCells");
}
