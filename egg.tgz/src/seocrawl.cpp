// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Crawl 500 pages, respect robots\n", stdout);
  return lionss_run_workload("seocrawl");
}
