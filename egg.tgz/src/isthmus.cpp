// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Amortization schedule"); }
int main(){
  announce();
  return lionss_run_workload("isthmus");
}
