// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Steady-state enclosure temps"); }
int main(){
  announce();
  return lionss_run_workload("thermal-enclosure");
}
