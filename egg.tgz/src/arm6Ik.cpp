// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Solve IK for 500 poses\n", stdout);
  return lionss_run_workload("arm6Ik");
}
