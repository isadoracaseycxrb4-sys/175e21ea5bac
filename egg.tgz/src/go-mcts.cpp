// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("2000 playouts per move, 10 moves"); }
int main(){
  announce();
  return lionss_run_workload("go-mcts");
}
