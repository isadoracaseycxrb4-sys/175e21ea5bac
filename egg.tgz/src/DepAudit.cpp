// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("Audit against advisory db\n", stdout);
  return lionss_run_workload("DepAudit");
}
