// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("DNL 65 contour\n", stdout);
  return lionss_run_workload("noise_contour");
}
