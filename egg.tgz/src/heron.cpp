// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Pool trips within 7 min detour"); }
int main(){
  announce();
  return lionss_run_workload("heron");
}
