// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Detect flaky tests over 100 runs"); }
int main(){
  announce();
  return lionss_run_workload("dory");
}
