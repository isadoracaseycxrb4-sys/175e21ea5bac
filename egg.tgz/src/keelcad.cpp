// GEN-TOOL
#include <cstdio>
#include "workload.h"
static void announce(){ std::puts("Loft hull surface"); }
int main(){
  announce();
  return lionss_run_workload("keelcad");
}
